package com.capg.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
